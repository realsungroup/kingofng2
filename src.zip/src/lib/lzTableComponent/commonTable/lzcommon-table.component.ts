/*
  name:通用表格
  date:2017-9-1
*/
import { Component, OnInit, Input, SimpleChanges, Output, EventEmitter, OnChanges, ViewChild } from '@angular/core';
import { BaseHttpService } from '../../../app/base-http-service/base-http.service';
import { Observable } from 'rxjs';
import { LZTab } from '../interface/tab.interface';
import { NzMessageService,NzModalService } from 'ng-zorro-antd';

@Component({
  selector: 'app-lzcommon-table',
  templateUrl: './lzcommon-table.component.html',
  styleUrls: ['./lzcommon-table.component.scss'],

})
export class LZcommonTableComponent implements OnInit, OnChanges {
  _menuRecordStr: string = 'MenuRecordCustEdit';//自定义按钮传递到服务器的name数据
  _theModalName: string = 'main';//弹出窗体的控制变量
  titleArr: any;//cmscolumninfo数据
  _selectData: any;//操作，详情选择的某个数据
  searchValue: string = '';//搜索框数据
  isMainData: boolean = true;//是否为主表数据
  _filterData: Array<any> = [];//下拉菜单数据
  _filterSelectObj: any = {};//下拉菜单选择的对象

  //公共参数
  @Input() isAutoData: boolean = false;//是否自动获取数据
  @Input() operationButton: Array<any>;//自定义按钮对象
  @Input() operationOrginButton: Array<boolean> = [false, false, false, false];//详情 操作 删除 按钮显示 
  @Input() tabs: Array<LZTab> = [];//窗体名称
  @Input() addFormName: string = '';//新增数据的窗体名称
  @Input() isEditCustomPosition: boolean = false;//是否自定义定位
  @Input() isAddCustomPosition: boolean = false;//是否自定义定位
  @Output() operationBtnNoti = new EventEmitter();//自定义按钮回调方法
  @Input() isAttachDataModal: boolean = false;

  @Input() filterString: string = '';
  @Input() filterData: Array<any> = [];//下拉菜单数据

  // 自动获取数据(所需参数)
  @Input() requestType: string = "GET";//获取数据的http请求方式
  @Input() requestUrl: string = '';//获取数据的url
  @Input() requestParams: any = {};//获取数据的参数(包含主表resid，cmswhere等参数)
  @Input() requestDataType: any = -1;//枚举dataType中某一个

  // 传入数据(所需参数)
  @Input() resid: string;//主表ID
  @Input() current = 0;//当前页数
  @Input() pageSize = 10;//一页pageSize条数据
  @Output() commonNotification = new EventEmitter();//更新回调事件

  _total = 1;//数据总数
  _dataSet = [];//获取的数据数组
  _loading = true;//loading加载界面是否显示

  constructor(protected _httpSev: BaseHttpService, private modalSev: NzModalService,private messageSev:NzMessageService) {

  }

  //监听输入数据的变化（自动获取数据状态下取出current，pageSize，resid数据）
  ngOnChanges(changes: SimpleChanges) {
    if (changes['requestParams'] && this.isAutoData) {
      this.current = this.requestParams['pageIndex'] + 1;
      this.pageSize = this.requestParams['pageSize'];
      this.resid = this.requestParams.resid;
    }

    if (changes['filterData']) {
      if (this.filterData.length) {
        this._filterSelectObj = this.filterData[0];
        this._refreshData();
      }
    }
  }

  ngOnInit() {
    this._refreshData();//首次加载数据
  }

  //获取数据
  _refreshData = () => {
    //自动取数据
    if (this.isAutoData) {
      if (Object.keys(this._filterSelectObj).length && this.filterString) {
        this.requestParams.cmswhere = this.filterString + "='" + this._filterSelectObj['value'] + "'";
      }
      this.requestParams.pageIndex = this.current - 1;
      this.requestParams.pageSize = this.pageSize;
      this.requestParams['key'] = this.searchValue;
      this._loading = true;
      if (this.isAttachDataModal) {
        this._httpSev.baseRequest(this.requestType, this.requestUrl, this.requestParams, this.requestDataType).subscribe(
          data => {
            if (data && Array.isArray(data['data'])) {
              this._dataSet = data['data'];
              this._total = data['total'];
            }
          },
          error => {
            this.messageSev.error("获取数据失败");
          },
          () => {
            this._loading = false;
          }
        )

        let url = this._httpSev.path.baseUrl + this._httpSev.path.getColumnsDefine;
        let param = {
          resid: this.requestParams['subResid']
        }
        this._httpSev.baseRequest("GET", url, param, -1).subscribe(
          data => {
            console.info(data)
            if (data && data.Error == 0) {
              let tmpTitleArr = [];
              let keys = Object.keys(data['data']);
              for (let i = 0; i < keys.length; i++) {
                let key = keys[i];
                let element = data['data'][key];
                tmpTitleArr.push({
                  id: element['ColName'],
                  text: element['ColDispName']
                })
              }
              this.titleArr = tmpTitleArr;
            }
          },
          err => {

          }
        )

      } else {
        this._httpSev.baseRequest(this.requestType, this.requestUrl, this.requestParams, this.requestDataType).subscribe(
          data => {
            if (data && data.error == 0) {
              this.titleArr = data['cmscolumninfo'];
              this._dataSet = data['data'];
              this._total = data['total'];
            }
          },
          error => {
            alert("获取数据失败")
          },
          () => {
            this._loading = false;
          }
        )
      }

    } else {
      this._loading = true;
      this.commonNotification.emit({//更新current，pageSize到外部，再获取数据从外部传入
        "current": this.current,
        "pageSize": this.pageSize,
        "fun": (data: any) => {
          this._loading = false;
          this.titleArr = data['cmscolumninfo'];
          this._dataSet = data['data'];
          this._total = data['total'];
        }
      });
    }

  };

  /***********按钮及输入框触发事件**************/
  //下拉菜单事件
  filterClick(event: any, filterObj: any) {
    this._filterSelectObj = filterObj;
    this._refreshData();
  }

  //输入框监听事件
  searchChange(val) {
    this._refreshData();
  }

  //新增事件
  addDataClick() {
    this._theModalName = 'addDataForm';
  }

  //详情事件
  detailClick(event, data, idx) {
    this._theModalName = 'form-readonly';
    this._selectData = Object.assign({}, data, { idx: idx });
  }

  //操作事件
  operationClick(event, data, idx) {
    this._theModalName = 'form';
    this._selectData = Object.assign({}, data, { idx: idx });//options : [{label:"label1",value:"value1"},{label:"label2",value:"value2"}]
    this.isMainData = true;
  }

  //附表事件
  attachTableClick(event, data, idx) {
    this._theModalName = 'form';
    this._selectData = Object.assign({}, data, { idx: idx });
    this.isMainData = false;
  }

  //删除事件
  deleteClick(data) {
    this.modalSev.open({
      title: "警告",
      content: "确认删除此条信息",
      onOk: () => {
        let path: any = this._httpSev.appConfig['path'];
        let url: string = path.baseUrl + path.saveData;
        let params: any = {
          'resid': this.resid,
          'data': data
        }
        this._loading = true;
        this._httpSev.baseRequest("POST", url, params, this._httpSev.dataT.DeleteOneDataEM).subscribe(
          data => {
            if(data){
              if(data['error'] == 0){
                this._refreshData();
              }else{
                this.messageSev.error(data['message']);
              }
            }
          },
          error => {
            console.error(JSON.stringify(error))
          },
          () => {
            this._loading = false;
          }
        )

      }
    })
  }

  //自定义按钮事件
  btnClick(event, i: number, data: any) {
    // let name = this._menuRecordStr + i;
    this.operationBtnNoti.emit({
      i: i,
      data: data
    });
  }

  /***********窗体通知事件**************/

  //详情窗体返回事件
  windowModalNoti() {
    this._theModalName = 'main';
  }

  //编辑表单窗体回调事件
  modalFormNoti(notiObj: any) {
    if (notiObj && notiObj.name == 'close') {
      this.windowModalNoti();
    } else if (notiObj && notiObj.name == 'update') {//刷新更新
      this.windowModalNoti();
      this._refreshData();
    } else if (notiObj && notiObj.name == 'update' && notiObj.data && notiObj.data.idx >= 0) {//本地更新（未用）

    }
  }

}
