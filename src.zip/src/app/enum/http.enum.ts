export enum dataType {
    LoginDefaultEM,
    LoginDynamicEM,
    LoginEM,
    HostTableDataEM,
    AddOneDataEM,
    AttachTableDataEM,
    FixOneDataEM,
    FixMoreDataEM,
    DeleteOneDataEM,
    AddMoreAndFixMore,
    UnKnow
};