import { Route } from '@angular/router';

// export interface CustomRoute extends Route{
//     link:string;
// }

// export interface CustomRoute{
//     link:string;
// }


// export interface aaaaaaaaaaa{
//     link:string;
// }

export interface aaaaaaaaaaa extends Route{
    link:string;
}