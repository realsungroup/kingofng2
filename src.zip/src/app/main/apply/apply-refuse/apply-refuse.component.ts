import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apply-refuse',
  templateUrl: './apply-refuse.component.html',
  styleUrls: ['./apply-refuse.component.scss']
})
export class ApplyRefuseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
