import { Component, OnInit } from '@angular/core';
import { BaseHttpService } from '../../../base-http-service/base-http.service';
import { NzMessageService } from 'ng-zorro-antd';

@Component({
  selector: 'app-clear-cache',
  templateUrl: './clear-cache.component.html',
  styleUrls: ['./clear-cache.component.scss']
})
export class ClearCacheComponent implements OnInit {

  constructor(private httpSev:BaseHttpService,private messageSev:NzMessageService) { }

  ngOnInit() {

  }

  clear(){
    let loading = this.messageSev.loading("清除中..."); 
    let url = this.httpSev.path.baseUrl + this.httpSev.path.clearCache;
    this.httpSev.baseRequest("GET",url,{},this.httpSev.dataT.UnKnow).subscribe(
      data => {
        this.messageSev.success("清除成功");
      },
      err => {
        this.messageSev.error("清除失败");
      },
      () => {
        this.messageSev.remove(loading.messageId);
      }
    )
  }

}
